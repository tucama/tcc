1. O diretório ./00_dataset contém arquivos .pdb que serão utilizados no seu trabalho de TCC.
   A nomeclatura dos resíduos destes pdbs estão de acordo com o campo de força AMBER, portanto, 
   será necessário realizar alguns ajustes, já que iremos utilizar o campo de força CHARMM. 
   Segue abaixo uma tabela com exemplos:

  AMBER | CHARMM
------------------
   HIE     HSE
   HIP     HSP
   HID     HSD
   CYX     CYS

2. No diretório ./00_dataset/1a4y/1a4y_A_D435 existe um arquivo de configuração do NAMD
intitulado "namd.conf", bem como arquivos de output do sistema (p/ você usar como exemplo).

Inseri uma modificação no protocolo de minimização, que agora será realizado em duas etapas.
    a) primeira minimização (10.000 passos) apenas para moléculas de água, enquanto a proteína é mantida fixa;
        a.1) os parâmetros de configuração no NAMD desta parte estão na seção "Fixed Atoms";
        a.2) para cada sistema você terá que preparar um arquivo .fix, que informa ao NAMD quais átomos serão 
             mantidos fixos durante a primeira minimização. No diretório ./_scripts existe um script intitulado
             "fixedatoms.tcl" que prepara este arquivo. Se possível, estude-o.
    b) segunda minimização (10.000 passos) para todos os átomos do sistema (sem restrição na proteína).

3. Ao término de cada minimização, extraia o último frame de cada trajetória para o diretório ./02_mopac.

4. Preparar um plot da "energia potencial vs. passos de minimização" para cada sistema.
